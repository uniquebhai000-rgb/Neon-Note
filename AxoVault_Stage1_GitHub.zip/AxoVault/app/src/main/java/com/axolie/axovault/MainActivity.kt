package com.axolie.axovault

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.axolie.axovault.navigation.AppNavHost
import com.axolie.axovault.ui.theme.AxoVaultTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            AxoVaultTheme {
                AppNavHost()
            }
        }
    }
}
