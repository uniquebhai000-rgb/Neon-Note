package com.axolie.axovault.navigation

import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.axolie.axovault.ui.common.PlaceholderScreen
import com.axolie.axovault.ui.splash.SplashScreen

object Routes {
    const val SPLASH = "splash"
    const val ONBOARDING = "onboarding"
    const val LOCK = "lock"
}

@Composable
fun AppNavHost(
    // Stage 2 replaces this stub with a real DataStore flag.
    isConfigured: Boolean = false
) {
    val nav = rememberNavController()
    NavHost(
        navController = nav,
        startDestination = Routes.SPLASH,
        enterTransition = { fadeIn() },
        exitTransition = { fadeOut() }
    ) {
        composable(Routes.SPLASH) {
            SplashScreen(onFinished = {
                val target = if (isConfigured) Routes.LOCK else Routes.ONBOARDING
                nav.navigate(target) { popUpTo(Routes.SPLASH) { inclusive = true } }
            })
        }
        composable(Routes.ONBOARDING) {
            PlaceholderScreen("Setup Wizard", "Coming in Stage 2: master password, PIN, biometrics, recovery.")
        }
        composable(Routes.LOCK) {
            PlaceholderScreen("Lock Screen", "Coming in Stage 2.")
        }
    }
}
