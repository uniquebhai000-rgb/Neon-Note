package com.axolie.axovault.ui.theme

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.drawOutline
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/** Colours of the RGB cycle at a given phase (0..1). First and last stop match, so it loops seamlessly. */
fun rgbColorsAt(phase: Float): List<Color> {
    val p = Axo.RgbPalette
    val n = p.size
    return (0..n).map { k ->
        val pos = phase * n + k
        val i = pos.toInt()
        val frac = pos - i
        lerp(p[i % n], p[(i + 1) % n], frac)
    }
}

@androidx.compose.runtime.Composable
fun rememberRgbPhase(durationMs: Int = 5000): Float {
    val t = rememberInfiniteTransition(label = "rgbPhase")
    val phase by t.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(durationMs, easing = LinearEasing), RepeatMode.Restart),
        label = "phase"
    )
    return phase
}

/** Animated rotating RGB neon outline. Works on any shape. */
fun Modifier.rgbBorder(
    shape: Shape = RoundedCornerShape(20.dp),
    width: Dp = 2.dp,
    durationMs: Int = 5000
): Modifier = composed {
    val phase = rememberRgbPhase(durationMs)
    drawWithContent {
        drawContent()
        val brush = Brush.sweepGradient(rgbColorsAt(phase), center = Offset(size.width / 2f, size.height / 2f))
        drawOutline(shape.createOutline(size, layoutDirection, this), brush, style = Stroke(width.toPx()))
    }
}
