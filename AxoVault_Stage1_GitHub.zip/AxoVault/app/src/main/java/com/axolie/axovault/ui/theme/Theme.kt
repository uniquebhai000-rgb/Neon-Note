package com.axolie.axovault.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

private val AxoDarkScheme = darkColorScheme(
    primary = Axo.NeonPurple,
    secondary = Axo.Cyan,
    tertiary = Axo.RgbPink,
    background = Axo.Amoled,
    surface = Axo.Surface,
    onPrimary = Axo.TextPrimary,
    onBackground = Axo.TextPrimary,
    onSurface = Axo.TextPrimary
)

private val AxoTypography = Typography(
    headlineLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Bold, fontSize = 32.sp, letterSpacing = 2.sp),
    titleLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.SemiBold, fontSize = 22.sp),
    bodyLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontSize = 16.sp, lineHeight = 24.sp),
    bodyMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontSize = 14.sp, lineHeight = 20.sp),
    labelLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Medium, fontSize = 14.sp, letterSpacing = 1.sp)
)

@Composable
fun AxoVaultTheme(content: @Composable () -> Unit) {
    // Stage 6 adds light mode and user-selected accent themes.
    MaterialTheme(colorScheme = AxoDarkScheme, typography = AxoTypography, content = content)
}
